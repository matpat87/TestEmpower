<?php
 // created: 2018-06-12 10:04:16
$dictionary['Account']['fields']['sls_ly_c']['inline_edit']='1';
$dictionary['Account']['fields']['sls_ly_c']['labelValue']='Sales Last Year';

 ?>