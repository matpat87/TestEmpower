<?php
 // created: 2018-06-14 11:16:29
$dictionary['OTR_OnTrack']['fields']['priority']['inline_edit']=true;
$dictionary['OTR_OnTrack']['fields']['priority']['comments']='An indication of the priorty of the issue';
$dictionary['OTR_OnTrack']['fields']['priority']['merge_filter']='disabled';

 ?>