<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_ASOL_WORKFLOWMANAGER']  = 'Gestor de Flujo de Trabajo de AlineaSol';
$mod_strings['LBL_ASOL_WORKFLOWMANAGER_DESC']  = 'Gestiona tus Procesos del Gestor de Flujo de Trabajo';
$mod_strings['LBL_ASOL_CLEANUP']  = 'Limpia la base de datos del WFM de AlineaSol';
$mod_strings['LBL_ASOL_CLEANUP_DESC']  = 'Limpia datos innecesarios';
$mod_strings['LBL_ASOL_MONITOR']  = 'Monitor del WFM de AlineaSol';
$mod_strings['LBL_ASOL_MONITOR_DESC']  = 'Pantalla de monitorizacion para gestionar los actuales nodos en ejecución';
$mod_strings['LBL_ASOL_REBUILD']  = 'Reensamblar los enganches lógicos del WFM de AlineaSol';
$mod_strings['LBL_ASOL_REBUILD_DESC']  = 'Reensamblar enganches lógicos; necesario para usar módulos instalados después del WFM';
$mod_strings['LBL_ASOL_WFM_PANEL']  = 'Gestor de Flujo de Trabajo de AlineaSol';
$mod_strings['LBL_ASOL_WFM_PANEL_DESC']  = 'Sección de configuración para Gestor de Flujo de Trabajo de AlineaSol';
$mod_strings['LBL_ASOL_CHECKCONFIGURATIONDEFS']  = 'Validar Funcionalidades Configuradas';
$mod_strings['LBL_ASOL_CHECKCONFIGURATIONDEFS_DESC']  = 'Validar Funcionalidades Configuradas';
$mod_strings['LBL_REPAIR_PHP_CUSTOM']  = 'Reparar ficheros php-custom';
$mod_strings['LBL_REPAIR_PHP_CUSTOM_DESC']  = 'Reparar ficheros php-custom';
$mod_strings['LBL_ABOUT_WFM']  = 'Acerca del WFM';
$mod_strings['LBL_ABOUT_WFM_DESC']  = 'Acerca del WFM';

?>