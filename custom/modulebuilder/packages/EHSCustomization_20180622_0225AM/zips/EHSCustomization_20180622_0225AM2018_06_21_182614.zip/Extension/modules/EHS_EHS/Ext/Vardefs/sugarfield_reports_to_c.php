<?php
 // created: 2018-06-20 18:10:42
$dictionary['EHS_EHS']['fields']['reports_to_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['reports_to_c']['labelValue']='Reports to';

 ?>