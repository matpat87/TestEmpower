<?php
 // created: 2018-06-12 07:23:23
$dictionary['User']['fields']['erpuserid_c']['inline_edit']='1';
$dictionary['User']['fields']['erpuserid_c']['labelValue']='ERP UID';

 ?>