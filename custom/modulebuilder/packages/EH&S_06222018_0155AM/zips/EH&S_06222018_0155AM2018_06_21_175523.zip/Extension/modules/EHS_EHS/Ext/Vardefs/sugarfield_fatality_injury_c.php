<?php
 // created: 2018-06-20 17:00:17
$dictionary['EHS_EHS']['fields']['fatality_injury_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['fatality_injury_c']['labelValue']='Fatality or Major Injury';

 ?>