<?php
 // created: 2018-06-23 07:21:03
$dictionary['RE_Regulatory']['fields']['date_received_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['date_received_c']['labelValue']='Notice of Violation Received';

 ?>