<?php
 // created: 2018-06-20 17:24:08
$dictionary['EHS_EHS']['fields']['legally_reportable_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['legally_reportable_c']['labelValue']='Legally Reportable';

 ?>