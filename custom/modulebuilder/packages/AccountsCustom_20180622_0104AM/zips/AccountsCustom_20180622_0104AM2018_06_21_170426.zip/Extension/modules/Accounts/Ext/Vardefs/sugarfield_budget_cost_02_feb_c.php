<?php
 // created: 2018-06-12 09:22:25
$dictionary['Account']['fields']['budget_cost_02_feb_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_02_feb_c']['labelValue']='February Cost';

 ?>