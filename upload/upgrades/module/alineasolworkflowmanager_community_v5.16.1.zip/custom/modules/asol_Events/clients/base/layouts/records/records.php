<?php

$module = 'asol_Events';

$viewdefs[$module]['base']['layout']['records'] = array(
	'name' => 'bwc',
	'type' => 'bwc',
	'components' =>
		array(
			array(
				'view' => 'bwc',
			),
	),
);