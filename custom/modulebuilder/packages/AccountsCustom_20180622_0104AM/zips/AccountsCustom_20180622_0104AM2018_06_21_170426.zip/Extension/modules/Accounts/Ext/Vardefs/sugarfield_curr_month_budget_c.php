<?php
 // created: 2018-06-12 08:47:16
$dictionary['Account']['fields']['curr_month_budget_c']['inline_edit']='1';
$dictionary['Account']['fields']['curr_month_budget_c']['labelValue']='Current Month Budget';

 ?>