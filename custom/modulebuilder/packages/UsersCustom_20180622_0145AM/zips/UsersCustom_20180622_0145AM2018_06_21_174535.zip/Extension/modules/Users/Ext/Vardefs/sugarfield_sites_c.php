<?php
 // created: 2018-06-12 07:41:09
$dictionary['User']['fields']['sites_c']['inline_edit']='1';
$dictionary['User']['fields']['sites_c']['labelValue']='Sites';

 ?>