<?php
 // created: 2018-06-12 09:50:13
$dictionary['Account']['fields']['address_latitude_c']['inline_edit']='1';
$dictionary['Account']['fields']['address_latitude_c']['labelValue']='Map Latitude';

 ?>