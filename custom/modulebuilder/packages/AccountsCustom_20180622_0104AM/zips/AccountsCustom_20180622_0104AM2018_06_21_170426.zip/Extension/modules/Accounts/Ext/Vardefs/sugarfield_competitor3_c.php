<?php
 // created: 2018-06-12 08:41:42
$dictionary['Account']['fields']['competitor3_c']['inline_edit']='1';
$dictionary['Account']['fields']['competitor3_c']['labelValue']='Competitor3';

 ?>