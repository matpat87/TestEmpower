<?php
 // created: 2018-06-12 10:17:14
$dictionary['Account']['fields']['volume_ytd_c']['inline_edit']='1';
$dictionary['Account']['fields']['volume_ytd_c']['labelValue']='Volume YTD';

 ?>