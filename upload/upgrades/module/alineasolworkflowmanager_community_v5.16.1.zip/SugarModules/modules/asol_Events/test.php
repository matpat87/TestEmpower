<?php

echo "<input type='button' value='test_dentro' />";

?>