<?php
 // created: 2018-06-12 09:58:14
$dictionary['Account']['fields']['order_cycle_c']['inline_edit']='1';
$dictionary['Account']['fields']['order_cycle_c']['labelValue']='Order cycle';

 ?>