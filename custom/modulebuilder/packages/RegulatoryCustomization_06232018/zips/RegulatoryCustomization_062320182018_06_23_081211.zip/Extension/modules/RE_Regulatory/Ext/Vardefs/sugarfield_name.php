<?php
 // created: 2018-06-23 06:54:00
$dictionary['RE_Regulatory']['fields']['name']['inline_edit']=true;
$dictionary['RE_Regulatory']['fields']['name']['duplicate_merge']='disabled';
$dictionary['RE_Regulatory']['fields']['name']['duplicate_merge_dom_value']='0';
$dictionary['RE_Regulatory']['fields']['name']['merge_filter']='disabled';
$dictionary['RE_Regulatory']['fields']['name']['unified_search']=false;

 ?>