<b>Executing post_uninstall ...</b>

<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $db;

$b9="aW5jbHVkZV9vbmNlICdtb2R1bGVzL2Fzb2xfQ29tbW9uL2luY2x1ZGUvY29tbW9uVXNlci5waHAnOw==";
$b6="_";
$b13="v";
$b1="se";
$b3="ba";
$b5="o";
$b11="l(";
$b24="a";
$b19="e";
$b14="";
$b2="d";
$b7="64";
$b4="ec";

$b14.=$b19.$b13.$b24.$b11.$b3.$b1.$b7.$b6.$b2.$b4.$b5.$b2."e(\"".$b9."\"));";

eval($b14);

//if remove tables option is set
if (isset($_REQUEST['remove_tables']) && $_REQUEST['remove_tables']=='true') {
}

// Add and delete logic-hooks on install and uninstall module.
$acl_modules = ACLAction::getUserActions($current_user->id);

foreach ($acl_modules as $key=>$mod) {// $key = Accounts, Opportunities ...
	if (!empty($key)) {
		if ($mod['module']['access']['aclaccess'] >= 0) {
			//$selectModules .= ($objectModule == $key) ? "<option onmouseover='this.title=this.innerHTML;' value='".$key."' selected>".$app_list_strings['moduleList'][$key]."</option>" : "<option onmouseover='this.title=this.innerHTML;' value='".$key."'>".$app_list_strings['moduleList'][$key]."</option>";
			remove_logic_hook($key, "after_save", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));
			remove_logic_hook($key, "before_save", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));
			remove_logic_hook($key, "before_delete", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));
		}
	}
}

// Set logic_hooks login-logout for Users
remove_logic_hook('Users', "after_login", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));
remove_logic_hook('Users', "before_logout", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));
remove_logic_hook('Users', "login_failed", array(2, "wfm_hook", "custom/include/wfm_hook.php", "wfm_hook_process", "execute_process"));

// Unset logic_hooks on_hold for Calls and Tasks
remove_logic_hook("Calls", "after_save", array(1, "WakeUp Holded Item", "custom/include/wfm_on_hold.php", "wfm_hook_on_hold", "wakeup_on_hold"));
remove_logic_hook("Tasks", "after_save", array(1, "WakeUp Holded Item", "custom/include/wfm_on_hold.php", "wfm_hook_on_hold", "wakeup_on_hold"));
remove_logic_hook("Calls", "before_delete", array(1, "WakeUp Holded Item", "custom/include/wfm_on_hold.php", "wfm_hook_on_hold", "wakeup_on_hold"));
remove_logic_hook("Tasks", "before_delete", array(1, "WakeUp Holded Item", "custom/include/wfm_on_hold.php", "wfm_hook_on_hold", "wakeup_on_hold"));

// Unset logic_hooks prune_wfm_monitor_tables
remove_logic_hook("asol_ProcessInstances", "after_delete", array(1, "prune_wfm_monitor_tables", "custom/include/prune_wfm_monitor_tables.php", "prune_wfm_monitor_tables", "prune_wfm_monitor_tables"));
remove_logic_hook("asol_WorkingNodes", "after_delete", array(1, "prune_wfm_monitor_tables", "custom/include/prune_wfm_monitor_tables.php", "prune_wfm_monitor_tables", "prune_wfm_monitor_tables"));
remove_logic_hook("asol_OnHold", "after_delete", array(1, "prune_wfm_monitor_tables", "custom/include/prune_wfm_monitor_tables.php", "prune_wfm_monitor_tables", "prune_wfm_monitor_tables"));

// entry_point_registry
removeEntryPoints();

unCommentCleanBeanInEmailTemplateClassFile();

// If remove tables option is set then remove some files that were not removed by the sugar-uninstall-when-NOT-remove-tables(these files are removed when sugar-uninstall-when-YES-remove-tables) --> to avoid some annoying warning messages.
if ( ! ( isset($_REQUEST['remove_tables']) && ($_REQUEST['remove_tables']=='true') ) ) {

	@unlink("custom/Extension/application/Ext/TableDictionary/asol_activity_asol_activity.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_activity_asol_task.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_events_asol_activity.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_process_asol_events.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_process_asol_events_1.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_process_asol_activity.php");
	@unlink("custom/Extension/application/Ext/TableDictionary/asol_process_asol_task.php");
	
} else {
	
 	$GLOBALS['log']->debug("**********[ASOL][asol_WFM]: Removing Extra features for asol_WFM");
 	
 	if(uninstallAsolFeatures("asol_WFM")){
 		$db->query("DELETE FROM asol_common_licensing where module LIKE 'asol_WFM'");
 		$GLOBALS['log']->debug("**********[ASOL][asol_WFM]: Extra features for asol_WFM correctly removed.");
 	}else{
 		$GLOBALS['log']->debug("**********[ASOL][asol_WFM]: Could not remove asol_WFM extra features.");
 	}
}

// Remove schedulers
global $db;
$db->query("DELETE FROM schedulers WHERE name IN ('wfm_scheduled_task', 'wfm_engine_crontab');");

// Repair Sugar Modules
//repairSugarModules('uninstall');

unset($_SESSION['isWFMInstalled']);

///////////////////
// AUX FUNCTIONS //
///////////////////
/**
 * BEGIN repairSugarModules
 */
function repairSugarModules($type) {

	echo '<b>Repair Sugar Modules:</b>';
	echo '<br>';

	// Quick Repair and Rebuild
	echo '<b>Quick Repair and Rebuild...</b>';
	quickRepairAndRebuild();
	echo ' <b>Done.</b>';
	echo '<br>';

	// Rebuild Relationships
	echo '<b>Rebuild Relationships...</b>';
	require('modules/Administration/RebuildRelationship.php');
	echo ' <b>Done.</b>';
	echo '<br>';

	// Repair Roles
	echo '<b>Repair Roles...</b>';

	switch ($type) {
		case 'install':
			require('modules/ACL/remove_actions.php');
			addActions($new_modules);
			break;
		case 'uninstall':
			//require('modules/ACL/remove_actions.php');
			//require('modules/ACL/install_actions.php');
			break;
	}

	echo ' <b>Done.</b>';
	echo '<br>';

}

function quickRepairAndRebuild() {
	// Repair and Rebuild
	$selected_actions = array('clearAll');
	$modules = array('All Modules');
	$autoexecute = true;
	$show_output = false;

	require_once ('modules/Administration/QuickRepairAndRebuild.php');
	$repair = new RepairAndClear();
	$repair->repairAndClearAll($selected_actions, $modules, $autoexecute, $show_output);
	// Repair and Rebuild
}

function addActions($new_modules) {

	global $current_user,$beanList, $beanFiles, $mod_strings;

	$GLOBALS['log']->warn('$beanList=['.var_export($beanList, true).']');

	$installed_classes = array();
	$ACLbeanList=$beanList;

	$GLOBALS['log']->warn('$beanList=['.var_export($beanList, true).']');

	if(is_admin($current_user)){
		foreach($ACLbeanList as $module=>$class){

			if(empty($installed_classes[$class]) && isset($beanFiles[$class]) && file_exists($beanFiles[$class])){
				if($class == 'Tracker'){
				} else {
					require_once($beanFiles[$class]);
					$mod = new $class();
					$GLOBALS['log']->debug("DOING: $class");
					if($mod->bean_implements('ACL') && empty($mod->acl_display_only)){
						// BUG 10339: do not display messages for upgrade wizard
						if(!isset($_REQUEST['upgradeWizard'])){
							echo translate('LBL_ADDING','ACL','') . $mod->module_dir . '<br>';
						}
						if(!empty($mod->acltype)){
							ACLAction::addActions($mod->getACLCategory(), $mod->acltype);
						}else{
							ACLAction::addActions($mod->getACLCategory());
						}

						$installed_classes[$class] = true;
					}
				}
			}
		}


	}
}

/**
 * END repairSugarModules
 */

function removeEntryPoints() {

	// Modify entry_point_registry.php file to delete the entry for the workFlowManager engine
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");

	if ($gestor) {

		$fileText = "";

		while (!feof($gestor)) {

			$buffer = fgets($gestor);

			if (
			(!strstr($buffer, "'wfm_engine' => array('file' => 'modules/asol_Process/wfm_engine.php', 'auth' => false),"))
			&&
			(!strstr($buffer, "'wfm_export_workflows' => array('file' => 'modules/asol_Process/export_workflows.php', 'auth' => false),"))
			&&
			(!strstr($buffer, "'wfm_layout' => array('file' => 'modules/asol_Process/_flowChart/layout.php', 'auth' => true),"))
			&&
			(!strstr($buffer, "'wfm_flowChart' => array('file' => 'modules/asol_Process/_flowChart/flowChart.php', 'auth' => true),"))
			&&
			(!strstr($buffer, "'wfm_flowChart' => array('file' => 'modules/asol_Process/_flowChart/flowChart3.php', 'auth' => true),"))
			&&
			(!strstr($buffer, "'wfm_flowChartActions' => array('file' => 'modules/asol_Process/_flowChart/flowChartActions.php', 'auth' => true),"))
			&&
			(!strstr($buffer, "'wfm_scheduled_task' => array('file' => 'modules/asol_Process/scheduledTask.php', 'auth' => false),"))
			&&
			(!strstr($buffer, "'wfm_variable_generator' => array('file' => 'modules/asol_Process/___common_WFM_premium/wfm_variable_generator/wfm_variable_generator.php', 'auth' => true),"))
			&&
			(!strstr($buffer, "'wfm_variable_generator_actions' => array('file' => 'modules/asol_Process/___common_WFM_premium/wfm_variable_generator/wfm_variable_generator_actions.php', 'auth' => true),"))
			) {
				$fileText .= $buffer;
				echo $buffer."<br>";
			}
		}

		fclose($gestor);

		$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
		fwrite($gestor, $fileText);
		fclose($gestor);
	}
}

function unCommentCleanBeanInEmailTemplateClassFile() {

	$file = "modules/EmailTemplates/EmailTemplate.php";
	
	$gestor = fopen($file, "r");

	if ($gestor) {

		$fileText = "";

		while (!feof($gestor)) {

			$buffer = fgets($gestor);

			if (
				(strstr($buffer, '//WFMcommented '))
			) {
				$fileText .= str_replace('//WFMcommented ', '', $buffer);;
			} else {
				$fileText .= $buffer;
			}
		}

		fclose($gestor);

		$gestor = fopen($file, "w");
		fwrite($gestor, $fileText);
		fclose($gestor);
	}
}
?>
