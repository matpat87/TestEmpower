<?php
 // created: 2018-06-12 09:41:30
$dictionary['Account']['fields']['inbox25_score_c']['inline_edit']='1';
$dictionary['Account']['fields']['inbox25_score_c']['labelValue']='INBOX25 Score';

 ?>