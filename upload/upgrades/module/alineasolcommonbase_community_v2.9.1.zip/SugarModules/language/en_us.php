<?php
$app_list_strings['moduleList']['asol_Common'] = 'Common';
?>