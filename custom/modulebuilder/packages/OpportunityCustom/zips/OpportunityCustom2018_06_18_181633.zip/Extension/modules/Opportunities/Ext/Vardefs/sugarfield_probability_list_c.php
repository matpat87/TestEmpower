<?php
 // created: 2018-06-18 16:59:43
$dictionary['Opportunity']['fields']['probability_list_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['probability_list_c']['labelValue']='Probability (%)';

 ?>