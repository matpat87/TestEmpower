<?php
 // created: 2018-06-12 09:47:55
$dictionary['Account']['fields']['last_year_ranking_c']['inline_edit']='1';
$dictionary['Account']['fields']['last_year_ranking_c']['labelValue']='Last Year Ranking';

 ?>