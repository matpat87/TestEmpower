<?php
 // created: 2018-06-12 09:42:31
$dictionary['Account']['fields']['initiatives_c']['inline_edit']='1';
$dictionary['Account']['fields']['initiatives_c']['labelValue']='Initiatives';

 ?>