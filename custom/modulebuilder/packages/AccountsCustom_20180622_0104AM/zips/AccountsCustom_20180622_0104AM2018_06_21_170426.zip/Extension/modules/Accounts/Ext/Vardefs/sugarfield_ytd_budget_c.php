<?php
 // created: 2018-06-12 10:17:45
$dictionary['Account']['fields']['ytd_budget_c']['inline_edit']='1';
$dictionary['Account']['fields']['ytd_budget_c']['options']='numeric_range_search_dom';
$dictionary['Account']['fields']['ytd_budget_c']['labelValue']='YTD Budget';
$dictionary['Account']['fields']['ytd_budget_c']['enable_range_search']='1';

 ?>