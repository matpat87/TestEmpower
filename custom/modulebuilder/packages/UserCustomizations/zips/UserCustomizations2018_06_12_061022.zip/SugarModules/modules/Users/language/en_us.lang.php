<?php 
 // created: 2018-06-12 06:10:15
$mod_strings['LBL_BUSINESSUNIT'] = 'Business Unit';

?>
