<?php 
 // created: 2018-06-26 16:23:54
$mod_strings['LBL_PRIORITY'] = 'Priority:';

?>
