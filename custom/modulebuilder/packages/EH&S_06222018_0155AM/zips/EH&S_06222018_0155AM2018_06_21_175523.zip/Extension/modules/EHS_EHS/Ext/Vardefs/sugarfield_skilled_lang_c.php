<?php
 // created: 2018-06-20 17:49:27
$dictionary['EHS_EHS']['fields']['skilled_lang_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['skilled_lang_c']['labelValue']='Skilled in Language';

 ?>