- If you are using sugarcrm 7.X then you need to perform a 'Quick Repair & Rebuild' after installing WFM.

- A new-version-WFM's zip may be installed if an old-version-WFM's zip is still installed. The new-version will replace the old-version. So, you do not need to uninstall the old-version in order to install the new-version. Therefore, you will not loose your configs for the WFM (module tab order, roles, etc).

- WFM creates automatically two Schedulers:
	a) wfm_engine_crontab
	b) wfm_scheduled_task
	
	- If the schedulers were not created or did not work properly:
		- Go to (in Sugarcrm) Admin->Schedulers:
			a) Create/modify wfm_engine_crontab Scheduler:
				- URL Scheduler =>  http://[your_server_IP or localhost]/[instance name]/index.php?entryPoint=wfm_engine&execution_type=crontab
			b) Create/modify wfm_scheduled_task Scheduler:
				- URL Scheduler =>  http://[your_server_IP or localhost]/[instance name]/index.php?entryPoint=wfm_scheduled_task

	- In order to run the SugarCRM schedulers (may differ depending on your server):
		Linux:
			- Open a terminal:
				- Type: vi /etc/crontab
					- Add:
						* * * * * nobody cd /opt/lampp/htdocs/[instance name] && /opt/lampp/bin/php -c /opt/lampp/etc/php.ini -f cron.php > /dev/null 2>&1 
					- (for bluehost, cron.php might avoid non-cli calls):
						* * * * * php-cli /home4/{username}/public_html/{subdomain}/cron.php
		Windows:
			- Create a batch file to run using Windows Scheduled Tasks. The batch file should include the following commands: 
				cd C:\xampp\htdocs\[instance_name] php.exe -f cron.php

- This WFM-zip needs the _fix_sugarcrmX_module_selfReferencing_bug-zip in order to use correctly the wfm-next_activities (there is a bug in sugarcrm-relationships).

- If your server:
	a) uses basic_authentication (site_login)
	b) is a virtualhost
	c) has some configuration to restrict http-requests
  and the WFM does not work -> refer to TROUBLESHOOTING.txt and config_override.php ($sugar_config['WFM_site_url'], $sugar_config['WFM_site_login_username_password'])
  
- If you experience some problem when using WFM -> refer to TROUBLESHOOTING.txt