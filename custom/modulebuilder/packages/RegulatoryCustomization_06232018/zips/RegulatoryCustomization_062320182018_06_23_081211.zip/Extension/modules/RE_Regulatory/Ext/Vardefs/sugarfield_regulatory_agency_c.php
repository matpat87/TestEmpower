<?php
 // created: 2018-06-23 07:22:40
$dictionary['RE_Regulatory']['fields']['regulatory_agency_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['regulatory_agency_c']['labelValue']='Regulatory Agency';

 ?>