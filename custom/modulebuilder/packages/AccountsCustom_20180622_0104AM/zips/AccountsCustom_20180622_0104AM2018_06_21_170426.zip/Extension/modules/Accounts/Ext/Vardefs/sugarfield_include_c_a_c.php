<?php
 // created: 2018-06-12 09:42:01
$dictionary['Account']['fields']['include_c_a_c']['inline_edit']='1';
$dictionary['Account']['fields']['include_c_a_c']['labelValue']='Include C of A';

 ?>