<?php
 // created: 2018-06-12 08:57:26
$dictionary['Account']['fields']['equipment_multi_c']['inline_edit']='1';
$dictionary['Account']['fields']['equipment_multi_c']['labelValue']='Equipment';

 ?>