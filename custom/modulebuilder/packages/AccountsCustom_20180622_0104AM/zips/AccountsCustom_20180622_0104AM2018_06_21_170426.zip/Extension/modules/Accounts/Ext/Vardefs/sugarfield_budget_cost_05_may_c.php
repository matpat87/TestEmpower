<?php
 // created: 2018-06-12 09:54:42
$dictionary['Account']['fields']['budget_cost_05_may_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_05_may_c']['labelValue']='May Cost';

 ?>