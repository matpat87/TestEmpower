<?php
 // created: 2018-06-12 09:49:36
$dictionary['Account']['fields']['managed_account_c']['inline_edit']='1';
$dictionary['Account']['fields']['managed_account_c']['labelValue']='Managed Account';

 ?>