<?php
 // created: 2018-06-12 07:18:13
$dictionary['User']['fields']['division_c']['inline_edit']='1';
$dictionary['User']['fields']['division_c']['labelValue']='Division';

 ?>