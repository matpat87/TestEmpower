<?php
 // created: 2018-06-23 07:18:38
$dictionary['RE_Regulatory']['fields']['visit_type_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['visit_type_c']['labelValue']='Visit Type';

 ?>