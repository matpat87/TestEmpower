<?php
 // created: 2018-06-12 10:08:49
$dictionary['Account']['fields']['sept_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['sept_volume_c']['labelValue']='September';

 ?>