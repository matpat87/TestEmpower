<?php
 // created: 2018-06-12 09:44:48
$dictionary['Account']['fields']['budget_cost_01_jan_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_01_jan_c']['labelValue']='January Cost';

 ?>