<?php
 // created: 2018-06-23 06:53:25
$dictionary['RE_Regulatory']['fields']['inspection_date_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['inspection_date_c']['labelValue']='Inspection Date';

 ?>