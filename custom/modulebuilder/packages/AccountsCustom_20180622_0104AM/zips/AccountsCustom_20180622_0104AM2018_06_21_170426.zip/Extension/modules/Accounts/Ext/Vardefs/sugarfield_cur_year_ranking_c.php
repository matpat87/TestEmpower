<?php
 // created: 2018-06-12 08:47:48
$dictionary['Account']['fields']['cur_year_ranking_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_ranking_c']['labelValue']='Current Year Ranking';

 ?>