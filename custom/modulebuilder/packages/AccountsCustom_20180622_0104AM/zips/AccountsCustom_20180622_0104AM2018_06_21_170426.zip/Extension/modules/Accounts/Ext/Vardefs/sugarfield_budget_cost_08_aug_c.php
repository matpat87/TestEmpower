<?php
 // created: 2018-06-12 08:33:46
$dictionary['Account']['fields']['budget_cost_08_aug_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_08_aug_c']['labelValue']='August Cost';

 ?>