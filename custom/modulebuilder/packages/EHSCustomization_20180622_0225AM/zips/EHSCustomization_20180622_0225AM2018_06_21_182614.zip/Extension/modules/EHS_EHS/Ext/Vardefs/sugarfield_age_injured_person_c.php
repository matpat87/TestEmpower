<?php
 // created: 2018-06-20 16:44:12
$dictionary['EHS_EHS']['fields']['age_injured_person_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['age_injured_person_c']['labelValue']='Age of Injured Person';

 ?>