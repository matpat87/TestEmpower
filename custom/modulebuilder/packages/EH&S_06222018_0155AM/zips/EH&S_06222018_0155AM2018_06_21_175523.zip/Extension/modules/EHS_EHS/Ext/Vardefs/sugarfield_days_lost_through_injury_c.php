<?php
 // created: 2018-06-20 16:35:09
$dictionary['EHS_EHS']['fields']['days_lost_through_injury_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['days_lost_through_injury_c']['labelValue']='Days Lost through Injury';

 ?>