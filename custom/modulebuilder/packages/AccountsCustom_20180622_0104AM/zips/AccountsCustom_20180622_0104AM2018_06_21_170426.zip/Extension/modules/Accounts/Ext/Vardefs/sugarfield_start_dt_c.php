<?php
 // created: 2018-06-12 08:48:59
$dictionary['Account']['fields']['start_dt_c']['inline_edit']='1';
$dictionary['Account']['fields']['start_dt_c']['labelValue']='Customer Since';

 ?>