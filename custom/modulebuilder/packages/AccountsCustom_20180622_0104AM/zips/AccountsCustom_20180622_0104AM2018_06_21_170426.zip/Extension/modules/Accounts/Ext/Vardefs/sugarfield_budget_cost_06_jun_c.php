<?php
 // created: 2018-06-12 09:47:29
$dictionary['Account']['fields']['budget_cost_06_jun_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_06_jun_c']['labelValue']='June Cost';

 ?>