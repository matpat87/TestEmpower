<?php
 // created: 2018-06-12 08:26:05
$dictionary['Account']['fields']['altsysid_c']['inline_edit']='1';
$dictionary['Account']['fields']['altsysid_c']['labelValue']='ALT SYS ID';

 ?>