<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_ASOL_PROCESS_ASOL_EVENTS_FROM_ASOL_EVENTS_TITLE'] = 'Eventos';
$mod_strings['LBL_ASOL_PROCESS_ASOL_EVENTS_1_FROM_ASOL_EVENTS_TITLE'] = 'Eventos (Papelera de Reciclaje)';
$mod_strings['LBL_ASOL_PROCESS_ASOL_ACTIVITY_FROM_ASOL_ACTIVITY_TITLE'] = 'Actividades (Papelera de Reciclaje)';
$mod_strings['LBL_ASOL_PROCESS_ASOL_TASK_FROM_ASOL_TASK_TITLE'] = 'Tareas (Papelera de Reciclaje)';
