<?php
 // created: 2018-06-18 16:58:50
$dictionary['Opportunity']['fields']['next_step_temp_c']['inline_edit']='1';
$dictionary['Opportunity']['fields']['next_step_temp_c']['labelValue']='Next Step';

 ?>