<?php
 // created: 2018-06-12 09:56:34
$dictionary['Account']['fields']['cur_year_month10_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month10_c']['labelValue']='October $';

 ?>