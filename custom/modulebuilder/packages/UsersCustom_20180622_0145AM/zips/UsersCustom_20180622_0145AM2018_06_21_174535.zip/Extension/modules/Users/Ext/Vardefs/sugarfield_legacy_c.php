<?php
 // created: 2018-06-12 07:24:44
$dictionary['User']['fields']['legacy_c']['inline_edit']='1';
$dictionary['User']['fields']['legacy_c']['labelValue']='Legacy';

 ?>