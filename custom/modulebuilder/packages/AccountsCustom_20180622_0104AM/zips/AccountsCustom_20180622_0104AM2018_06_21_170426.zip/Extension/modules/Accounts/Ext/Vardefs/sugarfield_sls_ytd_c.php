<?php
 // created: 2018-06-12 10:06:04
$dictionary['Account']['fields']['sls_ytd_c']['inline_edit']='1';
$dictionary['Account']['fields']['sls_ytd_c']['labelValue']='Sales YTD';

 ?>