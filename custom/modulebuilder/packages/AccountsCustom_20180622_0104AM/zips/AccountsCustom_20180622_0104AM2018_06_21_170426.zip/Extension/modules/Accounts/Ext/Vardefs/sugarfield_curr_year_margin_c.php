<?php
 // created: 2018-06-12 08:49:58
$dictionary['Account']['fields']['curr_year_margin_c']['inline_edit']='1';
$dictionary['Account']['fields']['curr_year_margin_c']['labelValue']='CY Margin';

 ?>