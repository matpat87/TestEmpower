<?php
 // created: 2018-06-23 07:00:31
$dictionary['RE_Regulatory']['fields']['status_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['status_c']['labelValue']='Status';

 ?>