<?php
 // created: 2018-06-20 16:36:09
$dictionary['EHS_EHS']['fields']['experience_role_years_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['experience_role_years_c']['labelValue']='Years';

 ?>