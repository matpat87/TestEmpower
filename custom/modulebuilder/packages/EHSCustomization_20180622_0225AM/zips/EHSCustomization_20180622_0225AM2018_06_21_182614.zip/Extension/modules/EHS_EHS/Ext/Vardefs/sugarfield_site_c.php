<?php
 // created: 2018-06-20 17:48:17
$dictionary['EHS_EHS']['fields']['site_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['site_c']['labelValue']='Site';

 ?>