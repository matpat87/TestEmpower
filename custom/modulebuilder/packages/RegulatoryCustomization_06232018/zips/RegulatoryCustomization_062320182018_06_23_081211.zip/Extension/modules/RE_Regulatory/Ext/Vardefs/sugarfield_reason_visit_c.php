<?php
 // created: 2018-06-23 07:21:41
$dictionary['RE_Regulatory']['fields']['reason_visit_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['reason_visit_c']['labelValue']='Reason for visit';

 ?>