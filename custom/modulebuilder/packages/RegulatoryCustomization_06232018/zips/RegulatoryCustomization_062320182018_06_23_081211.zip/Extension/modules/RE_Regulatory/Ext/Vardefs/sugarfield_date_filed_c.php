<?php
 // created: 2018-06-23 07:21:18
$dictionary['RE_Regulatory']['fields']['date_filed_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['date_filed_c']['labelValue']='Date Filed';

 ?>