<?php
 // created: 2018-06-12 09:51:10
$dictionary['Account']['fields']['mar_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['mar_volume_c']['labelValue']='March';

 ?>