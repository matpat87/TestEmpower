<?php
// created: 2011-03-22 13:25:17
$dictionary["asol_Events"]["fields"]["asol_events_asol_activity"] = array (
  'name' => 'asol_events_asol_activity',
  'type' => 'link',
  'relationship' => 'asol_events_asol_activity',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ASOL_EVENTS_ASOL_ACTIVITY_FROM_ASOL_ACTIVITY_TITLE',
);
