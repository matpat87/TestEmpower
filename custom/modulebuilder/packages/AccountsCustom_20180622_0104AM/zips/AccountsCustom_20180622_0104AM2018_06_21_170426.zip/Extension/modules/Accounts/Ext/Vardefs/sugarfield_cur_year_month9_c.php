<?php
 // created: 2018-06-12 10:09:18
$dictionary['Account']['fields']['cur_year_month9_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month9_c']['labelValue']='September $';

 ?>