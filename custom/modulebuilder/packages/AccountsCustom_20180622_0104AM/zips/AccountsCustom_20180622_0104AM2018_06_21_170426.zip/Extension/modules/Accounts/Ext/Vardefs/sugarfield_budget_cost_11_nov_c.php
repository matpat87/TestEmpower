<?php
 // created: 2018-06-12 09:55:51
$dictionary['Account']['fields']['budget_cost_11_nov_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_11_nov_c']['labelValue']='November Cost';

 ?>