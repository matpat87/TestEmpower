<?php
 // created: 2018-06-12 10:07:29
$dictionary['Account']['fields']['sector_c']['inline_edit']='1';
$dictionary['Account']['fields']['sector_c']['labelValue']='Sector';

 ?>