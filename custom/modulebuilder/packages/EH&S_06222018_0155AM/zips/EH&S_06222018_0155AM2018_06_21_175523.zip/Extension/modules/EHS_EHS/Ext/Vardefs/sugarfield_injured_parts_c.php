<?php
 // created: 2018-06-20 17:08:20
$dictionary['EHS_EHS']['fields']['injured_parts_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['injured_parts_c']['labelValue']='Injured Body Part';

 ?>