<?php
 // created: 2018-06-12 09:50:46
$dictionary['Account']['fields']['address_longitude_c']['inline_edit']='1';
$dictionary['Account']['fields']['address_longitude_c']['labelValue']='Map Longitude';

 ?>