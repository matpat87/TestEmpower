<?php
 // created: 2018-06-12 10:15:33
$dictionary['Account']['fields']['status_c']['inline_edit']='1';
$dictionary['Account']['fields']['status_c']['labelValue']='Status';

 ?>