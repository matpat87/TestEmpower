<?php
 // created: 2018-06-20 18:11:17
$dictionary['EHS_EHS']['fields']['actionitem_assigned_user_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['actionitem_assigned_user_c']['labelValue']='Action Item Assigned to';

 ?>