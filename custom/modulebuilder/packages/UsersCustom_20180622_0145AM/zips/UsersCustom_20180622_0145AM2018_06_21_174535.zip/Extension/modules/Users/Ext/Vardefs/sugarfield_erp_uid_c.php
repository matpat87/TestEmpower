<?php
 // created: 2018-06-12 07:20:10
$dictionary['User']['fields']['erp_uid_c']['inline_edit']='1';
$dictionary['User']['fields']['erp_uid_c']['labelValue']='ERP Sales UID';

 ?>