<?php

$entry_point_registry['commonAjaxActions'] = array(
	'file' => 'modules/asol_Common/ajaxActions.php', 
	'auth' => true
);
