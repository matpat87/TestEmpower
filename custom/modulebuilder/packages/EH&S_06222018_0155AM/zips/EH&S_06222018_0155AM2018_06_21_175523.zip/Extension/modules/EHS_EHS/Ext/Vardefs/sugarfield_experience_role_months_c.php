<?php
 // created: 2018-06-20 16:35:31
$dictionary['EHS_EHS']['fields']['experience_role_months_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['experience_role_months_c']['labelValue']='Months';

 ?>