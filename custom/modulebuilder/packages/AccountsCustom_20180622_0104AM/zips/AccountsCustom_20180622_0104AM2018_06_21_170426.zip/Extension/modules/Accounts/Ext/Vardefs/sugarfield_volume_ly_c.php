<?php
 // created: 2018-06-12 10:16:43
$dictionary['Account']['fields']['volume_ly_c']['inline_edit']='1';
$dictionary['Account']['fields']['volume_ly_c']['labelValue']='Volume Last Year';

 ?>