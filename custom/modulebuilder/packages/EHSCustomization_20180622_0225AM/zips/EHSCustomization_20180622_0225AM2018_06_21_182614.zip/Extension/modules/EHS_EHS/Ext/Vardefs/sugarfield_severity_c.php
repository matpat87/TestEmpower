<?php
 // created: 2018-06-20 17:47:05
$dictionary['EHS_EHS']['fields']['severity_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['severity_c']['labelValue']='Actual Severity Rating';

 ?>