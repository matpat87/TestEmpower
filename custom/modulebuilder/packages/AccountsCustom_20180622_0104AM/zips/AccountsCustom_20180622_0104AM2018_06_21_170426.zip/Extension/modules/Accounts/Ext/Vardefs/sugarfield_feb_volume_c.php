<?php
 // created: 2018-06-12 09:01:50
$dictionary['Account']['fields']['feb_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['feb_volume_c']['labelValue']='February';

 ?>