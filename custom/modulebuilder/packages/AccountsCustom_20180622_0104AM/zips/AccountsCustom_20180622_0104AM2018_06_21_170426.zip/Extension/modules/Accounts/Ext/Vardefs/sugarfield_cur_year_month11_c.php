<?php
 // created: 2018-06-12 09:55:31
$dictionary['Account']['fields']['cur_year_month11_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month11_c']['labelValue']='November $';

 ?>