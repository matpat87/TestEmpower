<?php
 // created: 2018-06-20 16:17:49
$dictionary['EHS_EHS']['fields']['witness_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['witness_c']['labelValue']='Witness';

 ?>