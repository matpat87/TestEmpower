<?php
 // created: 2018-06-12 10:14:40
$dictionary['Account']['fields']['business_relationship_c']['inline_edit']='1';
$dictionary['Account']['fields']['business_relationship_c']['labelValue']='SPF Business Relationship';

 ?>