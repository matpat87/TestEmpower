<?php
 // created: 2018-06-12 09:46:41
$dictionary['Account']['fields']['jun_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['jun_volume_c']['labelValue']='June';

 ?>