<?php
 // created: 2018-06-12 08:35:40
$dictionary['Account']['fields']['balance_c']['inline_edit']='1';
$dictionary['Account']['fields']['balance_c']['labelValue']='Balance';

 ?>