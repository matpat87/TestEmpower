<?php
 // created: 2018-06-20 18:09:54
$dictionary['EHS_EHS']['fields']['user_id_c']['inline_edit']=1;

 ?>