<?php
 // created: 2018-06-12 08:29:19
$dictionary['Account']['fields']['cur_year_month4_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month4_c']['labelValue']='April $';

 ?>