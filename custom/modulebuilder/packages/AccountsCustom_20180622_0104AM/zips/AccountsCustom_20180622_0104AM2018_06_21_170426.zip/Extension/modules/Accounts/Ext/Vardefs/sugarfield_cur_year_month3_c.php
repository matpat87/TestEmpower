<?php
 // created: 2018-06-12 09:51:35
$dictionary['Account']['fields']['cur_year_month3_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month3_c']['labelValue']='March $';

 ?>