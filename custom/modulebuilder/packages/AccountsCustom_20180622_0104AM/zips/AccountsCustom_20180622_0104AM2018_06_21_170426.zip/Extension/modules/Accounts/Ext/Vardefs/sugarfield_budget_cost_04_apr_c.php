<?php
 // created: 2018-06-12 08:30:01
$dictionary['Account']['fields']['budget_cost_04_apr_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_04_apr_c']['labelValue']='April Cost';

 ?>