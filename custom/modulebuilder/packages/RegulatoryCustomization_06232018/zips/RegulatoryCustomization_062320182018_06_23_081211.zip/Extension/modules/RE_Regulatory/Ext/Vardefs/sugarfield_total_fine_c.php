<?php
 // created: 2018-06-23 07:20:44
$dictionary['RE_Regulatory']['fields']['total_fine_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['total_fine_c']['labelValue']='Total Fine $';

 ?>