<?php
 // created: 2018-06-20 16:15:21
$dictionary['EHS_EHS']['fields']['findings_corrective_action_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['findings_corrective_action_c']['labelValue']='Findings, Immediate and Corrective Actions';

 ?>