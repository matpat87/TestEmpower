<?php
 // created: 2018-06-20 17:52:43
$dictionary['EHS_EHS']['fields']['time_shift_minutes_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['time_shift_minutes_c']['labelValue']='Minutes';

 ?>