<?php
 // created: 2018-06-20 17:01:47
$dictionary['EHS_EHS']['fields']['gender_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['gender_c']['labelValue']='Gender';

 ?>