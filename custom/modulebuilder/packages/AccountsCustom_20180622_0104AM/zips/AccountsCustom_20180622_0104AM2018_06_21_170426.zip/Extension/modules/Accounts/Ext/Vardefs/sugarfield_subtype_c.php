<?php
 // created: 2018-06-12 10:03:35
$dictionary['Account']['fields']['subtype_c']['inline_edit']='1';
$dictionary['Account']['fields']['subtype_c']['labelValue']='Sales Channel';

 ?>