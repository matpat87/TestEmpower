<?php
 // created: 2018-06-20 17:31:18
$dictionary['EHS_EHS']['fields']['period_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['period_c']['labelValue']='Period of Work Week';

 ?>