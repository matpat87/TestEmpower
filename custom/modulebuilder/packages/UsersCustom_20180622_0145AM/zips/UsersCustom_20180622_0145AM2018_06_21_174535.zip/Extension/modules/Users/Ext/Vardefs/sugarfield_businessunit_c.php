<?php
 // created: 2018-06-12 06:07:52
$dictionary['User']['fields']['businessunit_c']['inline_edit']='1';
$dictionary['User']['fields']['businessunit_c']['labelValue']='Business Unit';

 ?>