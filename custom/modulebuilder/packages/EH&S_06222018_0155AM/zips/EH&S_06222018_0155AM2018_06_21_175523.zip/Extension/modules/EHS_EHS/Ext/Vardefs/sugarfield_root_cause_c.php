<?php
 // created: 2018-06-20 17:46:09
$dictionary['EHS_EHS']['fields']['root_cause_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['root_cause_c']['labelValue']='Root Cause';

 ?>