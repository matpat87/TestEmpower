<?php
 // created: 2018-06-20 16:15:47
$dictionary['EHS_EHS']['fields']['first_name_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['first_name_c']['labelValue']='First Name';

 ?>