<?php
 // created: 2018-06-20 16:29:21
$dictionary['EHS_EHS']['fields']['return_date_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['return_date_c']['labelValue']='Work Date';

 ?>