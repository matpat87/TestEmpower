<?php
 // created: 2018-06-12 09:46:08
$dictionary['Account']['fields']['budget_cost_07_jul_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_07_jul_c']['labelValue']='July Cost';

 ?>