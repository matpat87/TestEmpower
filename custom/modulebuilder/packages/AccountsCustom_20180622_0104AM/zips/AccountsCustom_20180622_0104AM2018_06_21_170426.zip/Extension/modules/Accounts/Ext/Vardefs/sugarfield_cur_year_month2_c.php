<?php
 // created: 2018-06-12 09:02:22
$dictionary['Account']['fields']['cur_year_month2_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month2_c']['labelValue']='February $';

 ?>