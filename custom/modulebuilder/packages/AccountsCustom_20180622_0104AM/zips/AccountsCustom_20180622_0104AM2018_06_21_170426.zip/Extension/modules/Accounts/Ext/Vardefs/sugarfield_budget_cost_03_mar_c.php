<?php
 // created: 2018-06-12 09:51:53
$dictionary['Account']['fields']['budget_cost_03_mar_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_03_mar_c']['labelValue']='March Cost';

 ?>