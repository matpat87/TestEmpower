<?php
 // created: 2018-06-20 17:57:19
$dictionary['EHS_EHS']['fields']['type']['len']=100;
$dictionary['EHS_EHS']['fields']['type']['inline_edit']=true;
$dictionary['EHS_EHS']['fields']['type']['comments']='The type of issue (ex: issue, feature)';
$dictionary['EHS_EHS']['fields']['type']['merge_filter']='disabled';
$dictionary['EHS_EHS']['fields']['type']['options']='ehs_ehs_type_dom';
$dictionary['EHS_EHS']['fields']['type']['audited']=true;

 ?>