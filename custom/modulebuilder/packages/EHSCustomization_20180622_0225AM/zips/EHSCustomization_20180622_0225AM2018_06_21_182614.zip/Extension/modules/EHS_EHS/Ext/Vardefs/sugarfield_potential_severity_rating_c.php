<?php
 // created: 2018-06-20 17:39:51
$dictionary['EHS_EHS']['fields']['potential_severity_rating_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['potential_severity_rating_c']['labelValue']='Potential Severity Rating';

 ?>