<?php
 // created: 2018-06-12 08:33:09
$dictionary['Account']['fields']['cur_year_month8_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month8_c']['labelValue']='August $';

 ?>