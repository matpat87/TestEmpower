<?php
/***CONFIGURATOR***/


//!!!!!!!!!!!!!!!!!!!!---------KEEP EXISTING SUGARCRM CONFIGURATION OVERRIDES


/****************************************************************************************************************************************************************************/
// You have to change this global-variable in order to let the WFM know the server-url.
// This is needed to fork execution and web-user-control, we don´t want to make that the user waits for a http response.
// This configuration comes from a problem with virtualhosts.
// 1) So if you have your sugarcrm-instance (for example) at http://www.alineasol.com/mysugarcrm the WFM will execute cURLs towards $sugar_config['site_url'] (defined in config.php file).
// 2) Sometimes, there are issues with virtualhosts. Therefore you will need to write 'WFM_site_url' on your config_override in case you use a virtualhost, with the proper URL.

$sugar_config['WFM_site_url'] = 'http://[your_server_url]/[your_sugarcrm_instance_name]';  // Do not forget to remove the brackets.  // If the default configuration does not work, try using this sugar_config. Also if you want the WFM to execute as soon as posible -> use your internal server_IP (for example: 127.0.0.1, your NAT IP, etc).
$sugar_config['WFM_site_login_username_password'] = '[site_login_username]:[site_login_password]';
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Translate labels of module_fields
// Bear in mind that translate labels will slow down the performance of the WFM when defining the flows. Instead of show module_fields almost immediately, it might take some seconds(depending on the number of related_fields and relationships).
$sugar_config['WFM_TranslateLabels'] = true; // Only use this if you want to translate labels of module_fields
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Get fields from database in order to use them in the $new_bean and $old_bean arrays.
// Some fields are not included in the bean(by SugarBean.php). For example: module 'Cases' has the field 'case_number', this field has the property autoincrement. So when you save a record, you do not have the case_number in the bean, the case_number is autoincremented in database, and it is not back to the bean.

$sugar_config['WFM_get_fields_from_db'] = array (
	'[moduleTable1]' => array ('[field1]','[field2]'),
	'[moduleTable2]' => array ('[fielda]','[fieldb]', '[fieldc]'),
);
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// [Deprecated]
// SugarCrm 641 uses ISO-charset for emailTemplates. As of SugarCrm 656 uses UTF-charset.
// If you experience that your emails show some weird characters -> Use the following $sugar_config:

// $sugar_config['WFM_sugarcrm_emailTemplate_charset'] = 'ISO';
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// WFM_MAX_loops // In order to avoid infinite loops
// To avoid that the code crash when the user defines a process that performs an action that triggers its execution (trigger=on_modify, task_type=modify_object; trigger=on_create, task_type=create_object with objectModule=trigger_module).

$sugar_config['WFM_MAX_loops'] = '10'; // If you set this config to 'unlimited' => allowed unlimited loops => it could cause infinite-loops -> crash!
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// WFM_MAX_working_nodes_executed_in_one_php_instance // In order to avoid 'Error: Query limit of 1000 reached for Home module.'
// SugarCrm has a limitation of queries executed in a php-instance
// This will not skip the remaining executions -> WFM will send a curl to continue the wfm-execution

$sugar_config['WFM_MAX_working_nodes_executed_in_one_php_instance'] = '10'; // If you set this config to 'unlimited' => allowed unlimited wfm-executions in one php-instance => it could cause query-limit-erros -> crash!
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// WFM logs. WFM uses two log-levels by default:
// a) info level: tells you about important steps taken by the WFM
// 		- you can configure info level to be other level, for example: warn.
// b) debug level: minor steps

// Remember choose the sugarcrm-log_level: Administration->System Settings->Logger Settings->Log Level (I recommend log_level=warn)

$sugar_config['WFM_changeLogLevelFromFlowDebugTo'] = 'warn'; // warn(recommended), debug, ...
$sugar_config['WFM_changeLogLevelFromAsolTo'] = 'warn'; // warn(recommended), debug, ...

$sugar_config['asolLogLevelEnabled'] = true; 
$sugar_config['WFM_changeLogLevelFromAsolDebugTo'] = 'warn';  // asol(development), debug(production, recommended)

// Instead of logging to "sugarcrm.log" file, log to independent file "wfm.log".
$sugar_config['WFM_log_to_independent_file'] = false; // false(recommended)
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// If you do not want some fields to show in the module_fields-dropdownlist

$sugar_config['WFM_NonVisibleFields'] = array(
	"[module_name_1]" => array("[field_1]", "[field_2]"),
	"[module_name_2]" => array("[field_1]", "[field_2]", "[field_3]"),
);
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// If you want a different  metadata per domain (example: domain-mvna -> listview -> show domain_name; domain-brand -> listview -> do not show domain_name)

$sugar_config['WFM_use_metadata_per_domain'] = false;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Only for loginAudit wfm-module
$sugar_config['WFM_use_alternative_listview'] = false;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Only if asol_Domains is installed

$sugar_config['WFM_CanSeeAsolDomainIdField_Roles'] = array('[role_1]', '[role_2]', '...', '[role_n]');
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Development Mode

$sugar_config['WFM_development_mode'] = false; // You need to set this sugar_config to true in order to use sugar_configs below.

$sugar_config['WFM_development_mode_allowed_emails'] = Array('email@email_server.com', 'name@server.es'); // If you use the WFM to send an email to an address that is not within this array => The WFM will replace @ by @x, so the email will not be received by this address.
$sugar_config['WFM_development_mode_notAllowedEmails_textAddedToEmailAddress'] = 'XWFMnotAllowedEmailX'; // If you are in WFM_development_mode and you do not use an email in the WFM_development_mode_allowed_emails array then the email-address will be modified. Ex: name_not_allowed@server.es -> name_not_allowed@XWFMnotAllowedEmailXserver.es
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Hide WFM dashlets. Admin-users do not depend on this config, they always can see WFM dashlets.

$sugar_config['WFM_hideDashlets'] = true;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// We are having some issues with a javascript-plugin (TinyMCE) used to make the description-field work as a WYSIWYG editor. Only some installations are throwing these problems.
// WFM does not use this editor by default, it uses a standard textarea (the user is able to use this editor by means of this sugar_config).
 
$sugar_config['WFM_useTinyMCE'] = false;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Textarea encodes line-feeds as \n, but html encodes line-feeds as <br>.
// If a field(wfm-variable) that is a textarea is used in an email_template, wfm needs to execute the php-function nl2br. Sometimes textarea uses {ckeditor, tynimce, etc}, in this case you need to set this sugar_config to true. 
// $beanField = nl2br($beanField);

$sugar_config['WFM_sugarcrmEmailTemplateBody_doNotExecute_nl2br'] = false;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Disable WFM

$sugar_config['WFM_disable_wfm_completely'] = true;
$sugar_config['WFM_disable_wfmHook'] = false;
$sugar_config['WFM_disable_wfmScheduledTask'] = false;
$sugar_config['WFM_disable_workFlowManagerEngine'] = false;
/****************************************************************************************************************************************************************************/

/****************************************************************************************************************************************************************************/
// Performance issues 

// If you need to process several objects (ex: import several leads) you might experience some performance issues if the WFM is enabled. This is because the WFM needs to send cURL requests always (even if no workflow is defined) in order to execute asynchronous workflows. // 

$sugar_config['WFM_enable_async_sugar_job_queue'] = false; // Set to true in order to use sugar_job_queue
$sugar_config['WFM_disable_async_curl'] = false; // Set to true in order to avoid cURL requests in WFM (you can not use async_curl)

// If you set the above configs to true then you will avoid WFM's perfomance issues.

/****************************************************************************************************************************************************************************/


//////////////////////
///// ENTERPRISE /////
//////////////////////

/****************************************************************************************************************************************************************************/
// - External non CRM databases (the databases access must be configured in an array like the following):
$sugar_config['WFM_AlternativeDbConnections'] = array(
	0 => array(
		"asolReportsDbAddress" => '192.168.0.X', //Ip address
		"asolReportsDbUser" => "root", //Database access username
		"asolReportsDbPassword" => "", //Database access password
		"asolReportsDbName" => "ExternalDb_A", //Database name
		"asolReportsDbPort" => "3306", //Port
		"asolDefaultDbDomainIdField" => array ( //this array is not mandatory, may not be defined. It's used for Domains filtering
			"fieldName" => "IdDomain",
			"isNumeric" => true //true [Numeric] false [String]
		),
		"asolSpecificTableDomainIdField" => array ( //this array is not mandatory, may not be defined. It's used for Domains filtering
			"tableA_1" => array("fieldName" => "idDomain1", "isNumeric" => true),
			"tableA_2" => array("fieldName" => "idDomain2", "isNumeric" => true),
		),
		"asolAllowedTables" => array(
			"instance" => array("tableA", "tableC"),
			"domain" => array(),
		),
		"asolForbiddenTables" => array(
			"instance" => array(),
			"domain" => array(
				"idDomain1" => array("tableB"),
			),
		),
	),
	1 => array(
		"asolReportsDbAddress" => '192.168.0.Y',
		"asolReportsDbUser" => "root",
		"asolReportsDbPassword" => "",
		"asolReportsDbName" => "ExternalDb_B",
		"asolReportsDbPort" => "3307",
		"asolDefaultDbDomainIdField" => array (
			"fieldName" => "IdDomain",
			"isNumeric" => true
		),
		"asolSpecificTableDomainIdField" => array(
			"tableB_1" => array("fieldName" => "idDomain3", "isNumeric" => true),
			"tableB_2" => array("fieldName" => "idDomain4", "isNumeric" => true),
		),
		"asolAllowedTables" => array(
			"instance" => array(),
			"domain" => array(),
		),
	),
);

/****************************************************************************************************************************************************************************/

////////////////////////////////////
/////SUGARCRM STANDARD CONFIGS//////
////////////////////////////////////

/****************************************************************************************************************************************************************************/
// Max queries allowed

$sugar_config['resource_management']['default_limit'] = 1000;
/****************************************************************************************************************************************************************************/


/***CONFIGURATOR***/