<?php
 // created: 2018-06-12 08:40:58
$dictionary['Account']['fields']['competitor1_c']['inline_edit']='1';
$dictionary['Account']['fields']['competitor1_c']['labelValue']='Competitor 1';

 ?>