//var fieldName

$(document).ready(function(e){
	
	// alert(amount_usd_c1);
	//setInterval(ChangeValueOfAmount, 300);
});

function ChangeValueOfAmount()
{
	console.log('asd');
	var amountValue = '$ ' + amount_usd_c1;
	$('#amount').text(amountValue);
	//$('div[field="amount"]').text();

	if($('#amount').val())
	{
		$('#amount').blur(function(e){

		});
	}
}