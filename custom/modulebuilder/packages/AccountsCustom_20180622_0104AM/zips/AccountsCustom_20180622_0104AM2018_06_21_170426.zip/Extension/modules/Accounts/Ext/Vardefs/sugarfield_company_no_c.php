<?php
 // created: 2018-06-12 09:00:03
$dictionary['Account']['fields']['company_no_c']['inline_edit']='1';
$dictionary['Account']['fields']['company_no_c']['labelValue']='ERP ID';

 ?>