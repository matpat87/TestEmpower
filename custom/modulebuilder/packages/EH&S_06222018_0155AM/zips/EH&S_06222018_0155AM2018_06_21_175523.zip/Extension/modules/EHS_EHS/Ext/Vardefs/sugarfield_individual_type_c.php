<?php
 // created: 2018-06-20 17:03:29
$dictionary['EHS_EHS']['fields']['individual_type_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['individual_type_c']['labelValue']='Individual Type';

 ?>