<?php
 // created: 2018-06-23 07:19:43
$dictionary['RE_Regulatory']['fields']['site_c']['inline_edit']='1';
$dictionary['RE_Regulatory']['fields']['site_c']['labelValue']='Site';

 ?>