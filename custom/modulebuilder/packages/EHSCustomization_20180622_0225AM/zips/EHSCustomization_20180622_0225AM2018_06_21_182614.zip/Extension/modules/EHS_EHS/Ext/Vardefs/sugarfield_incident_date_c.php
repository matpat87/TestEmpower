<?php
 // created: 2018-06-20 16:34:05
$dictionary['EHS_EHS']['fields']['incident_date_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['incident_date_c']['labelValue']='Incident Date and Time';

 ?>