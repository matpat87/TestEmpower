<?php
 // created: 2018-06-20 16:40:06
$dictionary['EHS_EHS']['fields']['actual_risk_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['actual_risk_c']['labelValue']='Actual Risk';

 ?>