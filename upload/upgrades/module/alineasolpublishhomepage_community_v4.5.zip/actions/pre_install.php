<?php

if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $sugar_config, $db;

if(isset($sugar_config['suitecrm_version'])){
	die("<span style='color:red;'>Error:</span> This module is not compatible with <strong>SuiteCRM</strong>: <a href='https://alineasolutions.com/index.php/downloads.html' target='_blank'>Check the AlineaSol´s compatibility matrix.</a>");
}

$db_name = $sugar_config['dbconfig']['db_name'];

$result_cbinstalled=$db->query("SELECT id_name,name FROM upgrade_history WHERE id_name ='AlineaSolCommonBase' AND status = 'installed' AND enabled = 1");
if($result_cbinstalled->num_rows==0){
	die ("<span style='color:orange;'>Warning:</span> Please install the module <strong>AlineaSol Common Base</strong> first.");
}

	
//Editamos el fichero entry_point_registry.php para anadirle un nuevo entry point para la scheduled Tasks de los Reports
 
   $gestor = fopen("include/MVC/Controller/entry_point_registry.php", "r");
	
	if ($gestor) {
	
		$fileText = "";
	
		while ((!feof($gestor)) && (!strstr($buffer, '$entry_point_registry = array('))) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer;
		}
	
		$fileText .= "\t'getExportedHomepagesSQL' => array('file' => 'modules/Home/getExportedHomepagesSQL.php', 'auth' => true),\n";
		echo "'getExportedHomepagesSQL' => array('file' => 'modules/Home/getExportedHomepagesSQL.php', 'auth' => true),<br>";

		while (!feof($gestor)) {
	
			$buffer = fgets($gestor);
			$fileText .= $buffer; 
		}
	
	fclose($gestor);
	
	$gestor = fopen("include/MVC/Controller/entry_point_registry.php", "w");
	fwrite($gestor, $fileText);
	
	fclose($gestor);
  
  }
  
	
?>
