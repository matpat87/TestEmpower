<?php
 // created: 2018-06-20 18:04:55
$dictionary['EHS_EHS']['fields']['unsafe_conditions_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['unsafe_conditions_c']['labelValue']='Unsafe Conditions';

 ?>