<?php
 // created: 2018-06-20 18:11:17
$dictionary['EHS_EHS']['fields']['user_id2_c']['inline_edit']=1;

 ?>