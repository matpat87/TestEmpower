<?php
 // created: 2018-06-18 17:51:18
$dictionary['Opportunity']['fields']['amount_usd_c']['inline_edit']='';
$dictionary['Opportunity']['fields']['amount_usd_c']['labelValue']='Opportunity Amount: (USD $)';

 ?>