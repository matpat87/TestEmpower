<?php 
$app_list_strings['businessunit_list'] = array (
  'POLYURETHANE' => 'POLYURETHANE',
  'RUBBER' => 'RUBBER',
);