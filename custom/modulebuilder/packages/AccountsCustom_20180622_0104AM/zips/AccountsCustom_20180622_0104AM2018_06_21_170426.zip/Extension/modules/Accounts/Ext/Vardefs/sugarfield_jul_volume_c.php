<?php
 // created: 2018-06-12 09:45:19
$dictionary['Account']['fields']['jul_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['jul_volume_c']['labelValue']='July';

 ?>