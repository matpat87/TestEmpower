<?php
 // created: 2018-06-20 16:16:14
$dictionary['EHS_EHS']['fields']['incident_location_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['incident_location_c']['labelValue']='Location of Incident';

 ?>