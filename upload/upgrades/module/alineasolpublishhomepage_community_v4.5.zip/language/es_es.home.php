<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');
  
  $mod_strings['LBL_HOMEPAGE_ROLE'] = 'Rol de Página de Inicio';
  $mod_strings['LBL_HOMEPAGE_ROLE_SAVED'] = 'Nueva configuraci&oacute;n de inicio almacenada';
  $mod_strings['LBL_PUBLISH_HOME'] = 'Publicar Página de Inicio Actual';
  $mod_strings['LBL_SAVE_HOME'] = 'Guardar Página de Inicio';
  $mod_strings['LBL_PUBLISHED_HOME'] = 'Página de Inicio publicada para el rol seleccionado';
  $mod_strings['LBL_PUBLISHED_HOME_NONE'] = 'Página de Inicio publicada para todos los usuarios sin rol';
  $mod_strings['LBL_PUBLISHED_HOME_ALL'] = 'Página de Inicio publicada para todos los roles';
  $mod_strings['LBL_DOMAIN'] = 'Dominio';
  $mod_strings['LBL_COPY_TO'] = 'Copiar Actual a';
  $mod_strings['LBL_COPIED_HOME'] = 'Página de Inicio copiada';
  $mod_strings['LBL_HOMEPAGE_PRIORITY'] = 'Prioridad';
  $mod_strings['LBL_VIEW_PRIORITIES'] = 'Administrar Prioridades'; 
  $mod_strings['LBL_ROLES_PRIORITIES'] = 'Prioridades de Roles'; 
  $mod_strings['LBL_ROLE_PRIORITY'] = 'Prioridad del Rol'; 
  $mod_strings['LBL_CHANGE_PRIORITY'] = 'Cambiar Prioridad';
  $mod_strings['LBL_ROLE_NAME'] = 'Nombre del Rol'; 
  $mod_strings['LBL_DEFAULT'] = 'Por Defecto';
  $mod_strings['LBL_ALL'] = 'Todos';
  $mod_strings['LBL_ADD_NEW_TAB'] = 'Añadir Pestaña';
  $mod_strings['LBL_COPY_OF'] = 'Copia de';
  $mod_strings['LBL_MAIN_TAB'] = 'Pestaña Principal';
  $mod_strings['LBL_NEW_TAB'] = 'Crear';
  $mod_strings['LBL_TAB_NAME'] = 'Nombre de la Pestaña';
  $mod_strings['LBL_TAB_ORDER'] = 'Orden';
  $mod_strings['LBL_SAVE_TAB'] = 'Guardar';
  $mod_strings['LBL_DUPLICATE_TAB'] = 'Duplicar';
  $mod_strings['LBL_DELETE_TAB'] = 'Eliminar';
  $mod_strings['LBL_DELETE_TAB_ALERT'] = 'Estás seguro de eliminar la pestaña actual?';
  $mod_strings['LBL_MANAGE_TABS'] = 'Administrar'; 
  $mod_strings['LBL_MANAGE_TABS_TITLE'] = 'Administrar Pestañas'; 
  $mod_strings['LBL_NEW_TAB_NAME'] = 'Nueva Pestaña';
  $mod_strings['LBL_MAIN_CUSTOM_TAB'] = 'Pestaña Personal Principal';
  $mod_strings['LBL_ADD_ASOL_DASHLETS'] = 'Añadir Dashlet';
  
  $mod_strings['LBL_COMMON_BASE_NEEDED'] = 'Debes instalar <b>AlineaSol Common Base</b> %[v] como mínimo para ejecutar este módulo.';
 
  $mod_strings['LBL_ASOL_EXPORT_HOME_PAGES'] = 'Exportar Todos los HomePages';
  $mod_strings['LBL_ASOL_EXPORT_HOME_PAGES_DESC'] = 'Exportar Todos los HomePages';
  $mod_strings['LBL_ASOL_PUBLISH_HOME_PAGE_TITLE'] = 'Publish HomePage AlineaSol';
  $mod_strings['LBL_ASOL_PUBLISH_HOME_PAGE_PANEL_DESC'] = 'Sección de Configuración de Publish HomePage AlineaSol';

?>