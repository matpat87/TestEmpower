<?php
 // created: 2018-06-20 18:09:54
$dictionary['EHS_EHS']['fields']['investigator_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['investigator_c']['labelValue']='Lead Investigator';

 ?>