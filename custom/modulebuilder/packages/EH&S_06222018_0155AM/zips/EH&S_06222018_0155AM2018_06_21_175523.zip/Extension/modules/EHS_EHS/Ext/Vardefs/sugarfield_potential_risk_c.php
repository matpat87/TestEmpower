<?php
 // created: 2018-06-20 17:32:28
$dictionary['EHS_EHS']['fields']['potential_risk_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['potential_risk_c']['labelValue']='Potential Risk';

 ?>