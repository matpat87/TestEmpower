<?php
 // created: 2018-06-12 10:10:20
$dictionary['Account']['fields']['sites_c']['inline_edit']='1';
$dictionary['Account']['fields']['sites_c']['labelValue']='sitesSites';

 ?>