<?php
 // created: 2018-06-12 09:58:50
$dictionary['Account']['fields']['last_sold_dt_c']['inline_edit']='1';
$dictionary['Account']['fields']['last_sold_dt_c']['options']='date_range_search_dom';
$dictionary['Account']['fields']['last_sold_dt_c']['labelValue']='Order Date';
$dictionary['Account']['fields']['last_sold_dt_c']['enable_range_search']='1';

 ?>