<?php
 // created: 2018-06-12 10:05:36
$dictionary['Account']['fields']['salesregion_c']['inline_edit']='1';
$dictionary['Account']['fields']['salesregion_c']['labelValue']='Sales Region';

 ?>