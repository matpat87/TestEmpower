<?php
 // created: 2018-06-12 09:36:59
$dictionary['Account']['fields']['from_erp_c']['inline_edit']='1';
$dictionary['Account']['fields']['from_erp_c']['labelValue']='from erp';

 ?>