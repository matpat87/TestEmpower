<?php 
$app_list_strings['probability_list'] = array (
  10 => '10% - company taking multiple bids, early stage',
  33 => '33% finalist',
  75 => '75% - testing trials, if trial OK, expect to win',
  90 => '90% - Verbal Close',
  100 => '100% - First order complete – fulfilling.',
);