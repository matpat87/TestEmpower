<?php
 // created: 2018-06-12 08:32:13
$dictionary['Account']['fields']['aug_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['aug_volume_c']['labelValue']='August';

 ?>