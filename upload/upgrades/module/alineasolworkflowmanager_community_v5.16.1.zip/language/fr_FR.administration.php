<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$mod_strings['LBL_ASOL_WORKFLOWMANAGER']  = 'Gestionnaire de processus AlineaSol';
$mod_strings['LBL_ASOL_WORKFLOWMANAGER_DESC']  = 'G&eacute;rer vos processus';
$mod_strings['LBL_ASOL_CLEANUP']  = 'AlineaSol WFM nettoyage de la base de donn&eacute;es';
$mod_strings['LBL_ASOL_CLEANUP_DESC']  = 'Clean unnecessary data';
$mod_strings['LBL_ASOL_MONITOR']  = 'Surveiller AlineaSol WFM';
$mod_strings['LBL_ASOL_MONITOR_DESC']  = 'Ecran de contr&ocirc;le pour surveiller les noeuds de travail en cours';
$mod_strings['LBL_ASOL_REBUILD']  = 'Reconstruction des logic_hooks de AlineaSol WFM';
$mod_strings['LBL_ASOL_REBUILD_DESC']  = 'Reconstruction des logic_hooks; requise pour l&acute;utilisation de modules install&eacute;s après  AlineaSol WFM';
$mod_strings['LBL_ASOL_WFM_PANEL']  = 'Gestionnaire de processus AlineaSol';
$mod_strings['LBL_ASOL_WFM_PANEL_DESC']  = 'Configuration de la section pour AlineaSol Work Flow Manager';
$mod_strings['LBL_ASOL_CHECKCONFIGURATIONDEFS']  = 'Validate Configured Features';
$mod_strings['LBL_ASOL_CHECKCONFIGURATIONDEFS_DESC']  = 'Validate Configured Features';

?>