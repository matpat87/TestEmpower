<?php
 // created: 2018-06-12 08:39:29
$dictionary['Account']['fields']['carrier_c']['inline_edit']='1';
$dictionary['Account']['fields']['carrier_c']['labelValue']='carrier';

 ?>