<?php 

require_once("modules/asol_Process/___common_WFM/php/asol_utils.php");
wfm_utils::wfm_log('debug', "ENTRY", __FILE__);

?>

<script src="modules/asol_Process/views/javascript.js?version=<?php wfm_utils::echoVersionWFM(); ?>" type="text/javascript"></script>			
