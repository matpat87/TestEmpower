<?php 
 // created: 2018-06-21 17:45:30
$mod_strings['LBL_BUSINESSUNIT'] = 'Business Unit';
$mod_strings['LBL_DIVISION'] = 'Division';
$mod_strings['LBL_ERP_UID'] = 'ERP Sales UID';
$mod_strings['LBL_ERPUSERID_C'] = 'ERP UID';
$mod_strings['LBL_LEGACY'] = 'Legacy';
$mod_strings['LBL_MARITAL_STATUS'] = 'Marital Status';
$mod_strings['LBL_SALESREGION'] = 'Sales Region';
$mod_strings['LBL_SITES'] = 'Sites';
$mod_strings['LBL_LOGIN_AS'] = 'Login As';

?>
