<?php
 // created: 2018-06-12 09:56:54
$dictionary['Account']['fields']['budget_cost_10_oct_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_10_oct_c']['labelValue']='October Cost';

 ?>