<?php
 // created: 2018-06-20 17:22:29
$dictionary['EHS_EHS']['fields']['job_factors_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['job_factors_c']['labelValue']='Job Factors';

 ?>