<?php
 // created: 2018-06-12 10:04:42
$dictionary['Account']['fields']['sls_ptd_c']['inline_edit']='1';
$dictionary['Account']['fields']['sls_ptd_c']['labelValue']='Sales PTD';

 ?>