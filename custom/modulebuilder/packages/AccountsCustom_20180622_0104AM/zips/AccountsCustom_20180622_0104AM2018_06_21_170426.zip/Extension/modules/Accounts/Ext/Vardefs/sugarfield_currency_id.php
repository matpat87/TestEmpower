<?php
 // created: 2018-06-12 08:29:19
$dictionary['Account']['fields']['currency_id']['inline_edit']=1;

 ?>