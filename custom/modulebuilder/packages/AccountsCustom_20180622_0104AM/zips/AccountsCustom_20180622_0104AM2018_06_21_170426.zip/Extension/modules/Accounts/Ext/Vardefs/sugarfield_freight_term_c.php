<?php
 // created: 2018-06-12 09:34:27
$dictionary['Account']['fields']['freight_term_c']['inline_edit']='1';
$dictionary['Account']['fields']['freight_term_c']['labelValue']='freight term';

 ?>