<?php
 // created: 2018-06-12 08:51:59
$dictionary['Account']['fields']['budget_cost_12_dec_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_12_dec_c']['labelValue']='December Cost';

 ?>