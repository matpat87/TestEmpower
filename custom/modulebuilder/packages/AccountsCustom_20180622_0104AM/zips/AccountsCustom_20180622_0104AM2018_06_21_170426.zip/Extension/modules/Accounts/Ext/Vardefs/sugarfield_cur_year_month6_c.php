<?php
 // created: 2018-06-12 09:47:10
$dictionary['Account']['fields']['cur_year_month6_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month6_c']['labelValue']='June $';

 ?>