<?php
 // created: 2018-06-20 16:11:52
$dictionary['EHS_EHS']['fields']['action_items_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['action_items_c']['labelValue']='Action Item';

 ?>