<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

global $sugar_config, $db;


//if database tables don`t use InnoDB engine, change the engine to InnoDB
$db = DBManagerFactory::getInstance();
$db_name = $sugar_config['dbconfig']['db_name'];


//Querys para generar las tablas nuevas: reports y reports_config

$GLOBALS['log']->debug("ASOL ------------------------------------------------------- Creando tablas");

$db->query("CREATE TABLE IF NOT EXISTS ".$db_name.".`roles_homepage` (
  `id` char(36) NOT NULL,
  `role_id` varchar(255) NOT NULL,
  `tab_id` smallint NOT NULL,
  `tab_name` varchar(255) NOT NULL,
  `tab_order` smallint DEFAULT '1',
  `user_owner` char(36) DEFAULT NULL,
  `date_entered` datetime DEFAULT NULL,
  `date_modified` datetime DEFAULT NULL,
  `home_priority` tinyint DEFAULT '0',
  `custom_home` tinyint DEFAULT '0',
  `home_hash_stored` text,
  `home_hash_published` text,
  `asol_domain_id` char(36),
  PRIMARY KEY (`id`)) ENGINE=INNODB DEFAULT CHARSET=utf8;");
  

  
$GLOBALS['log']->debug("ASOL ------------------------------------------------------- Tablas creadas");


 //UPDATING MISSING FIELDS FOR NEW REPORTS VERSIONS
 
 /************************/
 /**alternative_database**/
 /************************/
 $check_asol_domain_id_rs = $db->query("SHOW COLUMNS FROM roles_homepage LIKE 'asol_domain_id'");
 $check_asol_domain_id_row = $db->fetchByAssoc($check_asol_domain_id_rs);
 if (empty($check_asol_domain_id_row))
 	$db->query("ALTER TABLE roles_homepage add COLUMN asol_domain_id char(36) DEFAULT NULL");

 //UPDATING MISSING FIELDS FOR NEW REPORTS VERSIONS
 

//Añadimos logic_hook al crear nuevo usuario
check_logic_hook_file("Users", "after_save", array(1, "Set Home Page", "custom/include/UserHooks.php", "UserHooks", "setHomePage"));
check_logic_hook_file("Users", "after_retrieve", array(1, "Reset Homepage", "custom/include/UserHooks.php", "UserHooks", "resetHomePage"));


//Eliminamos los ficheros de idioma de la cache
$dir = "cache/modules/Home/language/";
$directorio=opendir($dir); 

while ($archivo = readdir($directorio)) {
	if (endsWith(strtolower($archivo), ".php"))
		unlink ($dir.$archivo); 
}
closedir($directorio); 

function endsWith( $str, $sub ) {
	return ( substr( $str, strlen( $str ) - strlen( $sub ) ) == $sub );
}



//Repair and Rebuild
$module = array('All Modules');
$selected_actions = array('clearAll');

require_once ('modules/Administration/QuickRepairAndRebuild.php');
$randc = new RepairAndClear();
$randc->repairAndClearAll ( $selected_actions, $module, false, false );
//Repair and Rebuild


//*************************//
//***  ASOL Licensing   ***//
//*************************//

global $sugar_version;
if(preg_match( "/^6.*/", $sugar_version)) {
	echo "<script>document.location = 'index.php?module=Home&action=index';</script>";
} else {
	echo "<script>
                var app = window.parent.SUGAR.App;
                window.parent.SUGAR.App.sync({
                    callback: function(){
                        app.router.navigate('#bwc/index.php?module=Home&action=index', {trigger:true});
                    }});
            </script>";
}

//*************************//
//***  ASOL Licensing   ***//
//*************************//

?>
