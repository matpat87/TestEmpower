<?php 
 // created: 2018-06-18 18:22:41
$mod_strings['LBL_AMOUNT_USD'] = 'Opportunity Amount: (USD $)';
$mod_strings['LBL_PROBABILITY_LIST'] = 'Probability (%)';
$mod_strings['LBL_NEXT_STEP_TEMP'] = 'Next Step';
$mod_strings['LBL_NEXT_STEP'] = 'Next Step:';

?>
