<?php 
$app_list_strings['otr_ontrack_priority_dom'] = array (
  'P0' => 'Critical',
  'P1' => 'High',
  'P2' => 'Medium',
  'P3' => 'Low',
);