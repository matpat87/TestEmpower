<?php
 // created: 2018-06-20 16:17:27
$dictionary['EHS_EHS']['fields']['underlying_causes_c']['inline_edit']='1';
$dictionary['EHS_EHS']['fields']['underlying_causes_c']['labelValue']='Basic Underlying Causes';

 ?>