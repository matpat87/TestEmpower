<?php
 // created: 2018-06-12 09:43:41
$dictionary['Account']['fields']['jan_volume_c']['inline_edit']='1';
$dictionary['Account']['fields']['jan_volume_c']['labelValue']='January';

 ?>