<?php
 // created: 2018-06-12 07:29:34
$dictionary['User']['fields']['marital_status_c']['inline_edit']='1';
$dictionary['User']['fields']['marital_status_c']['labelValue']='Marital Status';

 ?>