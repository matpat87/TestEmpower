<?php
 // created: 2018-06-12 07:34:34
$dictionary['User']['fields']['salesregion_c']['inline_edit']='1';
$dictionary['User']['fields']['salesregion_c']['labelValue']='Sales Region';

 ?>