<?php
 // created: 2018-06-12 09:40:28
$dictionary['Account']['fields']['googlemapurl_c']['inline_edit']='1';
$dictionary['Account']['fields']['googlemapurl_c']['labelValue']='Google Map Link';

 ?>