<?php
 // created: 2018-06-18 17:16:02
$dictionary['Opportunity']['fields']['next_step']['inline_edit']='';
$dictionary['Opportunity']['fields']['next_step']['comments']='The next step in the sales process';
$dictionary['Opportunity']['fields']['next_step']['merge_filter']='disabled';
$dictionary['Opportunity']['fields']['next_step']['len']='255';

 ?>