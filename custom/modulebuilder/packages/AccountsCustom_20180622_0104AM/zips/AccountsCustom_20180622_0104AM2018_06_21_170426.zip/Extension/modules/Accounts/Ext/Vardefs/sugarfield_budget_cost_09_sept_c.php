<?php
 // created: 2018-06-12 10:09:37
$dictionary['Account']['fields']['budget_cost_09_sept_c']['inline_edit']='1';
$dictionary['Account']['fields']['budget_cost_09_sept_c']['labelValue']='September Cost';

 ?>