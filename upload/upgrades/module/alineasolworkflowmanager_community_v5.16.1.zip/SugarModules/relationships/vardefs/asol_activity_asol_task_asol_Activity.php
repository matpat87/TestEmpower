<?php
// created: 2011-04-05 11:16:12
$dictionary["asol_Activity"]["fields"]["asol_activity_asol_task"] = array (
  'name' => 'asol_activity_asol_task',
  'type' => 'link',
  'relationship' => 'asol_activity_asol_task',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_ASOL_ACTIVITY_ASOL_TASK_FROM_ASOL_TASK_TITLE',
);
