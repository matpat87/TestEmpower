<?php 
 // created: 2018-06-23 08:12:10
$mod_strings['LBL_DATE_FILED'] = 'Date Filed';
$mod_strings['LBL_DATE_RECEIVED'] = 'Notice of Violation Received';
$mod_strings['LBL_DIVISION'] = 'Division';
$mod_strings['LBL_INSPECTION_DATE'] = 'Inspection Date';
$mod_strings['LBL_NAME'] = 'Item ID #';
$mod_strings['LBL_REASON_VISIT'] = 'Reason for visit';
$mod_strings['LBL_REGULATORY_AGENCY'] = 'Regulatory Agency';
$mod_strings['LBL_SITE'] = 'Site';
$mod_strings['LBL_STATUS'] = 'Status';
$mod_strings['LBL_TOTAL_FINE'] = 'Total Fine $';
$mod_strings['LBL_VISIT_TYPE'] = 'Visit Type';

?>
