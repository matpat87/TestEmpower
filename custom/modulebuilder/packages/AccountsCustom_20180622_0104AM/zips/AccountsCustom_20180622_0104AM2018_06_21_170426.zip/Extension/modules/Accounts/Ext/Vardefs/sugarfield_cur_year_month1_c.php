<?php
 // created: 2018-06-12 09:44:15
$dictionary['Account']['fields']['cur_year_month1_c']['inline_edit']='1';
$dictionary['Account']['fields']['cur_year_month1_c']['labelValue']='cur year month1January $';

 ?>