<?php
 // created: 2018-06-12 08:03:22
$dictionary['Account']['fields']['client_potential_c']['inline_edit']='1';
$dictionary['Account']['fields']['client_potential_c']['labelValue']='Account Potential';

 ?>